package headfirst.designpatterns.iterator.dinermerger;

public interface Menu {
	public Iterator createIterator();
}
