package headfirst.designpatterns.factory.pizzaaf;

public class Onion implements Veggies {

	public String toString() {
		return "Onion";
	}
}
